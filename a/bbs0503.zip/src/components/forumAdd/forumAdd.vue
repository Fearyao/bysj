<template>
<div class="forumAdd">
    <el-row>
        <input type="text" placeholder="标题" v-model="forumTopic">
    </el-row>
    <el-row>
    <ul>
        <li><a class="el-icon-picture"></a>图片</li>
        <li><a class="el-icon-date"></a>表情</li>
    </ul>
    </el-row>
    <textarea cols="100" rows="10" v-model='forumContent'></textarea>
    <el-row>
    <button @click="forumAdd()">发表</button>
    </el-row>
</div> 
</template>

<script>
  export default {
    name: 'forumAdd',
    data() {
      return {
        forumTopic:'',
        forumContent:''
      }
    },
    methods: {
        forumAdd(){
        console.log(this.$store.state);
        this.$http.post('/api/forumAdd',{TUID:this.$store.state.loginId,forumTopic:this.forumTopic,forumContent:this.forumContent}).then(response => {
            // get body data
            }, response => {
            // error callback
            alert('error')
         });
        }
    },
    beforeCreate(){

    }
  }
</script>

<style lang="stylus">
.forumAdd
    input
        width:200px
    ul li
        list-style:none
        float:left
        margin-right:20px
        cursor:pointer
    button

</style>