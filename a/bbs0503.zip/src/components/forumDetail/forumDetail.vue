<template>
  <div class="forumDetail">
    <ul>
      <li>
        <el-row type="flex">
          <el-col :span="6" class="replyer">
            <h1>{{topicDetail.user_name}}</h1>
            <p>楼主</p>
          </el-col>
          <el-col :span="18" class="replyContent">
            <div class="reply">
              <p style="margin-left:20px">
                {{topicDetail.TContent}}
              </p>
              <div>
                <span style="float:right;margin-right:20px;border:1px solid #ddd;padding:5px;border-radius:2px;" @click="gotoReplyTopic()"><i class="el-icon-edit"></i>回复</span>
              </div>
            </div>
          </el-col>
        </el-row>
      </li>
    </ul>
    <ul v-for="(reply,index) in replys">
      <li>
        <el-row type="flex">
          <el-col :span="6" class="replyer">
            <h1>{{reply.user_name}}</h1>
            <p>{{index+1}}</p>
          </el-col>
          <el-col :span="18" class="replyContent">
            <div class="replyTo">
              @{{reply.RToUser}}:<br>
              <span style="margin-left:20px;">{{reply.RToContent}}</span>
            </div>
            <div class="reply">
              <p style="margin-left:20px">
                {{reply.RContent}}
              </p>
              <div>
                <span style="float:right;margin-right:20px;border:1px solid #ddd;padding:5px;border-radius:2px;" @click="gotoReply(reply)"><i class="el-icon-edit"></i>回复</span>
              </div>
            </div>
          </el-col>
        </el-row>
      </li>
    </ul>
    <div class="replyWrite">
      </el-row>
      <textarea cols="100" rows="10" v-model='replyContent'></textarea>
      <el-row>
        <button @click="replyAdd()">回复</button>
      </el-row>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'forumDetail',
    data() {
      return {
        btshow:'',
        replys: [],
        replyContent:'',
        replyToReply:'',
        topicDetail:''
      }
    },
    methods: {
      gotoReply(reply) {
        if(!this.$store.state.loginId){
          this.$alert('登陆后才能发表言论哦', '登陆', {
          confirmButtonText: '确定',
          callback: action => {
            this.$router.push('/loginPage');
          }
        });
          return
        }
        this.replyToReply=reply;
        var replyWrite = this.$el.querySelector('.replyWrite');
        document.body.scrollTop = replyWrite.offsetTop;
      },
      replyAdd(){
        this.$http.post('/api/replyAdd',{RUID:this.$store.state.loginId,RContent:this.replyContent,RToUser:this.replyToReply.user_name,RToContent:this.replyToReply.RContent,RTID:this.replyToReply.RTID}).then(response => {
          this.loadData()
            }, response => {
            // error callback
            alert('error')
         });    
      },
      loadData(){
        var rtid = this.$route.query.RTID;
        this.$http.post('/api/forumDetail', {
          RTID: rtid
        }).then(response => {
          // get body data
          var forumDetail = response.body;
          console.log(forumDetail);
          this.replys = forumDetail
        }, response => {
        // error callback
          alert('error')
        });        
      }
    },
    beforeCreate() {
      var rtid = this.$route.query.RTID;
      //获取楼主发言
      console.log('louzhu')
      this.$http.post('/api/topicDetail',{
        RTID:rtid
      }).then(response => {
        // get body data
        var topicDetail = response.body;
        console.log(topicDetail);
        this.topicDetail = topicDetail[0]
      }, response => {
        // error callback
        alert('error')
      });
      //跟帖者发言
      console.log('gengtieze')
      this.$http.post('/api/forumDetail', {
        RTID: rtid
      }).then(response => {
        // get body data
        var forumDetail = response.body;
        console.log(forumDetail);
        this.replys = forumDetail
      }, response => {
        // error callback
        alert('error')
      });
    }
  }

</script>




<style scoped>
  .forumDetail ul {
    padding: 0;
    margin: 0;
    list-style: none;
  }

  .forumDetail ul li {
    padding: 5px;
    margin: 5px;
    border: 1px solid #ccc;
  }

  .forumDetail ul li .replyer {
    padding: 0;
    margin: 0;
    border-right: 1px solid #ccc;
  }

  .forumDetail .replyContent {
    text-align: left;
  }

  .forumDetail .replyContent .replyTo {
    padding: 5px;
    margin: 10px;
    border: 1px solid #eee;
  }

</style>
