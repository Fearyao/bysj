<template>
<div class="">
<img src="../../static/uploads/yyao.jpg" alt="">
</div>
</template>
