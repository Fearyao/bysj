import Vue from 'vue'
import Router from 'vue-router'

//page
import Hello from '@/components/Hello'
import myPage from '@/components/myPage'
import loginPage from '@/components/loginPage/loginPage'
import userPage from '@/components/loginPage/userPage'
import indexPage from '@/components/indexPage/indexPage'
import registerPage from '@/components/registerPage/registerPage'
import forumDetail from '@/components/forumDetail/forumDetail'
import forumAdd from '@/components/forumAdd/forumAdd'
import userAdmin from '@/components/adminPage/userAdmin'
import forumAdmin from '@/components/adminPage/forumAdmin'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/hello',
      name: 'Hello',
      component: Hello
    },
    {
      path: '/myPage',
      name: 'myPage',
      component: myPage
    },
    {
      path: '/loginPage',
      name: 'loginPage',
      component: loginPage
    },
    {
      path: '/userPage',
      name: 'userPage',
      component: userPage
    },
    {
      path: '/indexPage',
      name: 'indexPage',
      component: indexPage
    },
    {
      path: '/registerPage',
      name: 'registerPage',
      component: registerPage
    },
    {
      path: '/forumDetail',
      name: 'forumDetail',
      component: forumDetail
    },
    {
      path: '/forumAdd',
      name: 'forumAdd',
      component: forumAdd
    },
    {
      path: '/userAdmin',
      name: 'userAdmin',
      component: userAdmin
    },
    {
      path: '/forumAdmin',
      name: 'forumAdmin',
      component: forumAdmin
    }
  ]
})
