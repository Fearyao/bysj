<template>
<div class="forumDetail">
  <ul>
    <li>
      <el-row type="flex">
        <el-col :span="6" class="replyer">
          <img v-if='topicDetail.head' :src='topicDetail.head' />
          <h1>{{topicDetail.user_name}}</h1>
          <p>楼主</p>
        </el-col>
        <el-col :span="18" class="replyContent" style="position:relative">
          <div class="reply">
            <p style="margin-left:20px">
              {{topicDetail.TContent}}
            </p>
            <div style="position:absolute;bottom:10px;right:20px">
              <el-button icon="edit" @click='gotoReplyTopic()' style="float:right;margin-bottom:10px">回复</el-button>
              <el-button icon="warning" @click='reportDivShow()' style="float:right;margin-right:20px">举报</el-button>
              <el-dialog title="举报" v-model="reportShow">
                <el-form :model="report">
                  <el-form-item label="举报类型" label-width="100px">
                    <el-select v-model="report.type" placeholder="举报类型">
                      <el-option label="恶心" value="恶心"></el-option>
                      <el-option label="反动" value="反动"></el-option>
                      <el-option label="其他" value="其他"></el-option>
                    </el-select>
                  </el-form-item>
                  <el-form-item label="举报原因" label-width="100px">
                    <el-input v-model="report.reason" auto-complete="off" style='width:500px'></el-input>
                  </el-form-item>
                </el-form>
                <div slot="footer" class="dialog-footer" style='text-align:center'>
                  <el-button @click="reportCancle()">取 消</el-button>
                  <el-button type="primary" @click="reportSubmit()">确 定</el-button>
                </div>
              </el-dialog>
            </div>
          </div>
        </el-col>
      </el-row>
    </li>
  </ul>
  <ul v-for="(reply,index) in replys" style="position:relative">
    <li>
      <el-row type="flex">
        <el-col :span="6" class="replyer">
          <img v-bind:src="reply.head" />
          <h1>{{reply.user_name}}</h1>
          <p>{{index+1}}</p>
        </el-col>
        <el-col :span="18" class="replyContent">
          <div class="replyTo">
            @{{reply.RToUser}}:<br>
            <span style="margin-left:20px;">{{reply.RToContent}}</span>
          </div>
          <div class="reply">
            <p style="margin-left:20px">
              {{reply.RContent}}
            </p>
            <p style="margin-left:20px" v-if='reply.TEmotion'>
              <img :src="reply.TEmotion">
            </p>
            <div style="position:absolute;bottom:10px;right:20px">
              <span>{{reply.RTime}}</span>
              <span style="border:1px solid #ddd;padding:5px;border-radius:2px;" @click="gotoReply(reply)"><i class="el-icon-edit"></i>回复</span>
            </div>
          </div>
        </el-col>
      </el-row>
    </li>
  </ul>
  <div class="replyWrite">

    <div class="forumPicUp">
      <el-upload class="upload-demo" ref="upload" action="/api/forumImg" :on-preview="handlePreview" :on-remove="handleRemove" :file-list="fileList" :data={id:this.$store.state.loginId} :auto-upload="false">
        <el-button slot="trigger" size="small" type="primary" @click='clearList()'>选取文件</el-button>
        <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
      </el-upload>
    </div>





    <textarea cols="100" rows="10" v-model='replyContent'></textarea>
    <el-row>
      <el-button @click="replyAdd()">回复</el-button>
    </el-row>
  </div>
</div>
</template>

<script>
export default {
  name: 'forumDetail',
  data() {
    return {
      btshow: '',
      replys: [],
      replyContent: '',
      replyToReply: '',
      topicDetail: '',
      replyto: 0,
      reportShow: false,
      report: {
        reportUid: '',
        reportedTid: '',
        type: '',
        reason: ''
      },
      fileList: []
    }
  },
  methods: {
    submitUpload() {
      this.$refs.upload.submit();
    },
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    clearList(){
      this.fileList=[]
    },
    gotoReply(reply) {
      this.replyto = 1;
      if (!this.$store.state.loginId) {
        this.$alert('登陆后才能发表言论哦', '登陆', {
          confirmButtonText: '确定',
          callback: action => {
            this.$router.push('/loginPage');
          }
        });
        return
      }
      this.replyToReply = reply;
      var replyWrite = this.$el.querySelector('.replyWrite');
      document.body.scrollTop = replyWrite.offsetTop;
    },
    gotoReplyTopic(reply) {
      this.replyto = 0;
      if (!this.$store.state.loginId) {
        this.$alert('登陆后才能发表言论哦', '登陆', {
          confirmButtonText: '确定',
          callback: action => {
            this.$router.push('/loginPage');
          }
        });
        return
      }
      this.replyToReply = this.topicDetail;
      var replyWrite = this.$el.querySelector('.replyWrite');
      document.body.scrollTop = replyWrite.offsetTop;
    },
    replyAdd() {
      if (this.replyto == 0) {
        console.log(this.topicDetail)
        this.$http.post('/api/replyAdd', {
          RUID: this.$store.state.loginId,
          RContent: this.replyContent,
          RToUser: this.topicDetail.user_name,
          RToContent: this.topicDetail.TContent,
          RTID: this.topicDetail.TID
        }).then(response => {
          this.submitUpload()
        }, response => {
          // error callback
          alert('error')
        })
      } else {
        this.$http.post('/api/replyAdd', {
          RUID: this.$store.state.loginId,
          RContent: this.replyContent,
          RToUser: this.replyToReply.user_name,
          RToContent: this.replyToReply.RContent,
          RTID: this.$route.query.RTID
        }).then(function(){
          this.submitUpload()
        })
      }
      let self=this
      setTimeout(function(){
           self.loadData()
      },200)
    },
    reportDivShow() {
      if (!this.$store.state.loginId) {
        this.$alert('登陆后才能举报', '登陆', {
          confirmButtonText: '确定',
          callback: action => {
            this.$router.push('/loginPage');
          }
        });
        return
      }
      this.reportShow = false;
      this.reportShow = true;
      this.report.reportUid = this.$store.state.loginId;
      this.report.reportedTid = this.topicDetail.TID;
    },
    reportCancle() {
      this.reportShow = false;
    },
    reportSubmit() {
      console.log(this.report)
      this.$http.post('/api/forumReport', {
        report: this.report
      }).then(response => {
        this.reportShow = false
      }, response => {
        alert('error')
      });

    },
    loadData() {
      var rtid = this.$route.query.RTID;
      this.$http.post('/api/forumDetail', {
        RTID: rtid
      }).then(response => {
        // get body data
        var forumDetail = response.body;
        console.log(forumDetail);
        this.replys = forumDetail
      }, response => {
        // error callback
        alert('error')
      });
      this.replyto=0;
      this.replyContent='';
      this.fileList=[]
    }
  },
  beforeCreate() {
    var rtid = this.$route.query.RTID;
    //获取楼主发言
    console.log('louzhu')
    this.$http.post('/api/topicDetail', {
      RTID: rtid
    }).then(response => {
      // get body data
      var topicDetail = response.body;
      console.log(topicDetail);
      this.topicDetail = topicDetail[0]
    }, response => {
      // error callback
      alert('error')
    });
    //跟帖者发言
    console.log('gengtieze')
    this.$http.post('/api/forumDetail', {
      RTID: rtid
    }).then(response => {
      // get body data
      var forumDetail = response.body;
      console.log(forumDetail);
      this.replys = forumDetail
    }, response => {
      // error callback
      alert('error')
    });
  }
}
</script>




<style scoped>
.forumDetail ul {
  padding: 0;
  margin: 0;
  list-style: none;
}

.forumDetail ul li {
  padding: 5px;
  margin: 5px;
  border: 1px solid #ccc;
}

.forumDetail ul li .replyer {
  padding: 0;
  margin: 0;
  border-right: 1px solid #ccc;
}

.forumDetail .replyContent {
  text-align: left;
}

.forumDetail .replyContent .replyTo {
  padding: 5px;
  margin: 10px;
  border: 1px solid #eee;
}

img {
  width: 150px;
  height: 150px;
}
</style>
