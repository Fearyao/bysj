<template>
<div class="forumAdd">
  <el-row>
    <el-input type="text" placeholder="标题" v-model="forumTopic"></el-input>
  </el-row>
  <el-row>
    <ul>
      <li>
        <a class="el-icon-picture"></a>图片</li>
      <li>
        <a class="el-icon-date"></a>表情</li>
    </ul>
  </el-row>
  <el-row>
    <textarea cols="100" rows="10" v-model='forumContent'></textarea><br>
  </el-row>
  <el-row>
    <el-button @click="forumAdd()">发表</el-button>
  </el-row>
</div>
</template>

<script>
export default {
  name: 'forumAdd',
  data() {
    return {
      forumTopic: '',
      forumContent: ''
    }
  },
  methods: {
    forumAdd() {
      console.log(this.$store.state);
      this.$http.post('/api/forumAdd', {
        TUID: this.$store.state.loginId,
        forumTopic: this.forumTopic,
        forumContent: this.forumContent
      }).then(response => {
        // get body data
      }, response => {
        // error callback
        alert('error')
      });
    }
  },
  beforeCreate() {

  }
}
</script>

<style lang="stylus">
.forumAdd
    .el-input
        width:200px
        float:left
        margin-left:160px
    ul
        padding-left:160px
        li
            list-style:none
            float:left
            margin-right:20px
            cursor:pointer
    textarea



</style>
