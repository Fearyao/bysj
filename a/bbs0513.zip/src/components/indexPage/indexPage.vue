<template>
<div class="indexPage ">

  <el-row type="flex">
    <el-carousel class="carousel" :interval="4000" type="card" height="200px">
      <el-carousel-item v-for="item in 6">
        <div></div>
      </el-carousel-item>
    </el-carousel>
  </el-row>

  <el-row type="flex">
    <div class="user">
      <ul>
        <li @click='lifePage()'>生活</li>
        <li @click='artPage()'>文学</li>
        <li @click='gamePage()'>游戏</li>
        <li @click='otherPage()'>其他</li>
      </ul>
    </div>
    <div class="content">
      <div class="forumSearch">
        <el-row :gutter="4">
          <el-col :span="8" :offset="13">
            <el-input v-model="search" placeholder=''></el-input>
          </el-col>
          <el-col :span="2">
            <el-button type="primary" @click='forumSearch()'>查找</el-button>
          </el-col>
        </el-row>
      </div>
      <ul v-for="bbs in bbsinfo">
        <li @click="gotoBbs(bbs)">
          <h2>{{bbs.TTopic}}</h2>
          <p>{{bbs.TContent}}</p>
          <span>{{bbs.Ttime}}</span>
        </li>
      </ul>
    </div>
  </el-row>

  <div class="block" v-if='pageShow'>
    <el-pagination @current-change="handleCurrentChange" :current-page="currentPage" :page-size="10" layout="prev, pager, next, jumper" :total="total">
    </el-pagination>
  </div>

</div>
</template>


<script>
export default {
  name: 'indexPage',
  data() {
    return {
      bbsinfo: [],
      currentPage: 1,
      total: 0,
      search: '',
      pageShow:true
    }
  },
  methods: {
    lifePage(){
      this.$store.dispatch('changeTSID',{tsid:1})
      this.$router.push('/lifePage')
    },
    artPage(){
      this.$store.dispatch('changeTSID',{tsid:2})
      this.$router.push('/artPage')
    },
    gamePage(){
      this.$store.dispatch('changeTSID',{tsid:3})
      this.$router.push('/gamePage')
    },
    otherPage(){
      this.$store.dispatch('changeTSID',{tsid:4})
      this.$router.push('/otherPage')
    },
    loadData() {
      this.$http.post('/api/forumList', {
        current: this.page
      }).then(response => {
        // get body data
        var forumList = response.body;
        console.log(forumList);
        this.bbsinfo = forumList
      }, response => {
        // error callback
        alert('error')
      });
    },
    handleCurrentChange(val) {
      this.currentPage = val;
      console.log(`当前页: ${val}`);
      this.page = (this.currentPage - 1) * 10;
      this.$http.post('/api/forumList', {
        current: this.page
      }).then(response => {
        var forumList = response.body;
        console.log(forumList);
        this.bbsinfo = forumList
      }, response => {
        // error callback
        alert('error')
      });
    },
    forumSearch() {
      this.$http.post('/api/forumSearch', {
        search: this.search
      }).then(response => {
        var forumList = response.body;
        console.log(forumList);
        this.bbsinfo = forumList;
        this.pageShow=false
      }, response => {
        // error callback
        alert('error')
      });
    },
    gotoBbs(bbs) {
      var url = '/#/forumDetail?RTID=' + bbs.TID
      location.href = url;
    }
  },
  beforeCreate() {
    this.$http.post('/api/forumListInit', {}).then(response => {
      // get body data
      var forumList = response.body;
      console.log(forumList);
      if (forumList.length > 10) {
        this.total = forumList.length;
        forumList.length = 10
      }
      this.bbsinfo = forumList
    }, response => {
      // error callback
      alert('error')
    });
  }
}
</script>


<style>
.indexPage {
  margin: 0;
  padding: 0;
}

.indexPage .carousel {
  width: 100%;
}

.indexPage .carousel div {
  height: 98%;
  border: 1px solid #ccc;
}

.indexPage .user {
  width: 210px;
  margin: 0;
  padding: 0;
  border: 1px dotted #ccc;
  height: 1000px;
  background: rgb(246, 246, 251)
}

.indexPage .content {
  width: 780px;
}

.indexPage .content ul {
  list-style: none;
  padding: 0;
  margin: 5px;
}

.indexPage .content ul li {
  border-bottom: 1px solid #ccc;
  margin: 0;
  padding: 10px;
  text-align: left;
  cursor: pointer;
  border-radius: 5px;
  overflow: hidden
}

.indexPage .content ul li span {
  float: right;
  margin-right: 10px;
}
</style>
